## Overview of application

This is a Meme generator application. This application is very easy to use and will help any non technical user to generate there own memes, download it to there system/ mobiles. This is a responsive react based application.

## Steps to Run the application

### `npm install`

To install all the dependencies and create node modules folder.

### `npm start`

Runs the app in the development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.

## Other available Scripts

In the project directory, you can run:

### `npm run build`

Builds the app for production to the `build` folder.
It correctly bundles React in production mode and optimizes the build for the best performance.
