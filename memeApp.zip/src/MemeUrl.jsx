export const memeUrl1 = "https://api.imgflip.com/get_memes";
export const memeUrl2 = "https://api.imgflip.com/caption_image"